#!/usr/bin/env python
import time
import serial
import io
#import sys.getopt


ser = serial.Serial(
	port='/dev/ttyUSB0',
	baudrate = 1200,
	parity=serial.PARITY_NONE,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS,
        timeout = 1
)
#	xonxoff=False,
#	rtscts=False,
#	dsrdtr=False,

#ser2 = serial.Serial(
#	port='/dev/ttyUSB1',
#	baudrate = 1200,
#	parity=serial.PARITY_NONE,
#	stopbits=serial.STOPBITS_ONE,
#	bytesize=serial.EIGHTBITS,
#	xonxoff=True,
#	rtscts=False,
#	dsrdtr=False
#)



while 1:
	#screen = ser2.readline()
	#ser.write(screen)
	#screen = ser.readline()
	#screen = ser.readline()
	#print  "Screen Data  : " + repr(screen)
	ser.write(b'\x11\x20')
	time.sleep(1)
	motor = ser.readline()
	#ser2.write(motor)
	print  "Motor Data   : " + repr(motor)

	
