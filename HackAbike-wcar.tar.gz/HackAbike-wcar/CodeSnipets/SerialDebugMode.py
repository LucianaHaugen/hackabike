#!/usr/bin/env python
import time
import serial
import io
import time
import RPi.GPIO as GPIO

motor = serial.Serial(
	port='/dev/ttyUSB0',
	baudrate = 1200,
	parity=serial.PARITY_NONE,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS,
	timeout= 1
)

screen = serial.Serial(
	port='/dev/ttyUSB1',
	baudrate = 1200,
	parity=serial.PARITY_NONE,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS,
	timeout= 1
)

def destroy():
	screen.close()
	motor.close()
	pass

def loop():
	while 1:
		motor.write('hello')
		print  "MotorTx   : "
		time.sleep(1)
		screen.write('hello')
		print  "ScreenTx   : "
		time.sleep(1)

if __name__ == '__main__':
	try:
		loop()
	except KeyboardInterrupt:
		destroy()
