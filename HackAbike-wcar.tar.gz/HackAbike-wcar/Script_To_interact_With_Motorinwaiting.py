#!/usr/bin/env python
import time
import serial
import io
import time
import RPi.GPIO as GPIO
from threading import Event , Thread

#HELLO DEMO
interrupt=0
event=Event()
motor = serial.Serial(
	port='/dev/ttyUSB0',
	baudrate = 1200,
	parity=serial.PARITY_NONE,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS,
	timeout=0.012
)
screen = serial.Serial(
	port='/dev/ttyUSB1',
	baudrate = 1200,
	parity=serial.PARITY_NONE,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS,
)


def destroy():
	motor.close()
	screen.close()
	pass

           
class SniffThread(Thread):
 
        def __init__(self):
                ''' Constructor. '''
                Thread.__init__(self)
 
 
        def run(self):
           while 1:
                #Read Screen Data
                screendata = screen.readline()
                moreBytes = screen.inWaiting()
                while moreBytes:
                        screendata = screendata + screen.read(moreBytes)
			moreBytes = screen.inWaiting()
                #Write to motor
                motor.write(screendata)
                #Read Motor Data
                moreBytes=0
                motordata = motor.readline()
                moreBytes = motor.inWaiting()
                while moreBytes:
                        motordata = motordata + motor.read(moreBytes)
	                moreBytes = motor.inWaiting()
		print moreBytes
                #Write to screen
                screen.write(motordata)
                print  "Motor Data   : "  + repr(motordata)
                print  "Screen Data   : " + repr(screendata)
                print len(motordata)
		print len(screendata) 
		#interrupt for thread
                if interrupt == 1:
                        event.set()
                        #time.sleep(0.1)
             

if __name__ == '__main__':
        try:
                # Declare objects of MyThread class
                myThreadOb1 = SniffThread()
                myThreadOb1.start()
                myThreadOb1.join()
        except KeyboardInterrupt:
                destroy()



#####################################################
def motor_read_write(str):
                interrupt=1
                event.wait()
                motor.write(str)
                motordata = motor.read(1)
                moreBytes = motor.inWaiting()
                if moreBytes:
                        motordata = motordata + motor.read(moreBytes)
                #print  "Motor Data   : "  + repr(motordata)
                event.clear()
                interrupt=0
                return motordata;

def screen_read_write(str):
                interrupt=1
                event.wait()
                screen.write(str)
                screendata = screen.read(1)
                moreBytes = screen.inWaiting()
                if moreBytes:
                        screendata = screendata + screen.read(moreBytes)
                #print  "Screen Data   : " + repr(screendata)
                event.clear()
                interrupt=0
                return screendata;
