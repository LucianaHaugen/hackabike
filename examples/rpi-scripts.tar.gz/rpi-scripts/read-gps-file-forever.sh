#!/bin/bash

while :
do
        /root/read-gps-file-slowly.sh /root/example-data-gps.txt
done
