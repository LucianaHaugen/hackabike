#!/bin/bash

while :
do
        /root/read-info1-slowly.sh /root/example-data-info1.txt
done
