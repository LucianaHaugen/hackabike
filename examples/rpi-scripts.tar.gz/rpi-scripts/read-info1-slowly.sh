#!/bin/bash
while IFS='' read -r line || [[ -n "$line" ]]; do
    TIMESTAMP=`echo $(($(date +%s%N)/1000000))`
    echo "$line" | sed "s/TIMESTAMP/$TIMESTAMP/" | sed "s/BIKENR/7/" >/tmp/latest-info1
    sleep 4
done < "$1"
